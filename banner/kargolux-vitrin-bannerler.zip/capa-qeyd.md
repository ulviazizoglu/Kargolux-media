# Vitrin bannerləri – çap qeydi (2026-10-21)
- 8 PDF, hər biri Ulvinin göndərdiyi ChatGPT faylı ilə eyni ölçüdə (sm): 145x180 sol (sürətli), 145x180 sağ (İspaniya), 90x180 qapı (gəl-al), 51x215 dar (gəl-al, Xalqlar/Sərhədçi), 230x315 x2, 285x270, 240x98.
- Səhifə ölçüsü dəqiq kəsim ölçüsüdür (bleed yoxdur), 1 səhifə, PDF 1.4, RGB.
- Bütün yazılar əyriyə (curve) çevrilib, PDF-də şrift yoxdur. Kargolux, Zara, Mango, H&M, Amazon, Trendyol, Temu loqoları vektordur.
- Fon (səhnə, maskot, kölgələr) tək JPEG-dir (keyfiyyət 95): 145x180, 90x180, 51x215 üçün 150 dpi; 230x315 və 285x270 üçün 100 dpi; 240x98 üçün 120 dpi. Şəffaflıq/maska yoxdur.
- v2 (2026-10-21 axşam): aşağıdakı tünd zolaq yoxdur, şəkil aşağıya qədər bütövdür; kargolux.az sarı düymədə. Trendyol loqosu böyüdülüb. Kargolux loqosu furqonun, təyyarənin, qutuların üstünə qoyulub (menbe/brand_scenes.py).
- Mənbə: menbe/gen.py (SVG/HTML), render.js (Chromium PDF), fix.py (səhifəni dəqiq ölçüyə gətirir). Fonlar AI ilə yaradılıb, 4x böyüdülüb (Real-ESRGAN).
